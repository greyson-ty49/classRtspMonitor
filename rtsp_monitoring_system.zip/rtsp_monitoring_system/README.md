# RTSP 流监控系统

这是一个基于 Flask 和 Python 的 RTSP 流监控系统，可以同时监控多个 RTSP 流，并使用 AI 分析内容，检测不当言论。

## 功能特点

- 网页界面管理多个 RTSP 流
- 自动分段录制视频
- 提取音频并使用 Whisper 进行语音识别
- 使用 DeepSeek API 分析文本内容，检测不当言论
- 实时显示检测到的不当言论
- 通过 WebSocket 实时更新流状态

## 系统要求

- Python 3.8+
- FFmpeg
- 网络连接 (用于 DeepSeek API 调用)

## 安装说明

### 安装依赖项

1. 安装 FFmpeg (如果尚未安装)

   Ubuntu/Debian:
   ```bash
   sudo apt update
   sudo apt install ffmpeg
   ```

   CentOS/RHEL:
   ```bash
   sudo yum install ffmpeg ffmpeg-devel
   ```

   Windows:
   - 下载 FFmpeg: https://ffmpeg.org/download.html
   - 将 FFmpeg 添加到系统 PATH

2. 安装 Python 依赖

   ```bash
   pip install -r requirements.txt
   ```

   注意：Whisper 模型会在首次运行时自动下载，这可能需要一些时间。

### 配置

1. DeepSeek API 密钥

   在 `rtsp_recorder.py` 文件中，找到以下行并替换为您的 API 密钥:
   ```python
   DEEPSEEK_API_KEY = "sk-271d1b380e2d4aa1b0e1fd7b0412eca6"
   ```

2. 其他配置选项

   您可以在 `rtsp_recorder.py` 中的 `Config` 类中调整以下参数:
   - `SEGMENT_DURATION`: 视频分段时长（秒）
   - `WHISPER_MODEL`: Whisper 模型大小 ("tiny", "base", "small", "medium", "large")
   - `LANGUAGE`: 语音识别语言

## 运行应用

启动 Web 服务器:

```bash
python app.py
```

默认情况下，应用将在 http://localhost:5000 上运行。

## 使用说明

1. 添加 RTSP 流
   - 在左侧表单中输入教室 ID、教师姓名和 RTSP 流地址
   - 点击"添加"按钮

2. 管理 RTSP 流
   - 点击单个流旁边的"启动监控"或"停止监控"按钮
   - 使用右上角的"监控所有"或"停止所有"按钮批量操作

3. 查看不当言论
   - 左下方区域会实时显示系统检测到的不当言论

## 技术架构

- **Flask**: Web 应用框架
- **Flask-SocketIO**: 提供 WebSocket 支持，实现实时更新
- **FFmpeg**: 处理 RTSP 流和音频提取
- **Whisper**: OpenAI 的开源语音识别模型
- **DeepSeek API**: 用于文本内容分析

## 故障排除

1. **问题**: 无法连接到 RTSP 流
   - 确保 RTSP URL 格式正确且可访问
   - 检查网络连接和防火墙设置

2. **问题**: Whisper 模型下载失败
   - 检查网络连接
   - 手动下载模型并放置在正确的目录

3. **问题**: DeepSeek API 调用失败
   - 验证 API 密钥是否正确
   - 检查网络连接

4. **问题**: 网页界面无法显示
   - 检查 Flask 服务器是否正在运行
   - 查看浏览器控制台错误信息

## 日志文件

- `rtsp_recorder.log`: 核心 RTSP 录制和分析模块的日志
- `rtsp_web.log`: Web 界面的日志

查看这些文件可以帮助诊断问题。

## 贡献与支持

如有问题或改进建议，请联系系统管理员。